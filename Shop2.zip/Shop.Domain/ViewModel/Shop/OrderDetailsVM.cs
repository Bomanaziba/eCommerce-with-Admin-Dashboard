﻿using Shop.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Domain.ViewModel.Shop
{
    public class OrderDetailsVM
    {
        public OrderDetailsVM()
        {
            CreatedAt = DateTime.UtcNow;
        }

        public int OrderId { get; set; }

        public int Quantity { get; set; }

        public DateTime CreatedAt { get; set; }

        public virtual OrderDTO Orders { get; set; }

        public int ProductId { get; set; }

        public virtual ProductDTO Products { get; set; }

    }
}
