﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Domain.ViewModel.Account
{
    public class UserNavPartialVM
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
