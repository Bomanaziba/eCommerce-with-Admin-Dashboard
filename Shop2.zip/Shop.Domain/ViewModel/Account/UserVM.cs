﻿using Shop.Domain.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Domain.ViewModel.Account
{
    public class UserVM
    {
        public UserVM()
        {
            CreatedAt = DateTime.UtcNow;
        }


        public UserVM(UserDTO row)
        {
            Id = row.UserId;
            FirstName = row.FirstName;
            LastName = row.LastName;
            EmailAddress = row.EmailAddress;
            Username = row.UserName;
            Password = row.Password;
            IsActve = row.IsActive;
        }

        public int Id { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        public string EmailAddress { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string ConfirmPassword { get; set; }

        public bool IsActve { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
