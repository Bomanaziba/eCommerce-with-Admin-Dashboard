﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web.Mvc;

namespace Shop.Domain.Model
{
    [Table("tblSidebars")]
    public class SidebarDTO
    {
        [Key]
        public int Id { get; set; }
        [AllowHtml]
        public string Body { get; set; }
        public DateTime CreatedAt { get; set; }

        public bool IsActive { get; set; }
    }
}
