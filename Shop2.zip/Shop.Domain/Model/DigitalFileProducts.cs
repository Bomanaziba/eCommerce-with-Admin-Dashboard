﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Domain.Model
{
    [Table("DigitalFileProducts")]
    public class DigitalFileProducts
    {
        [Key]
        public int DigitalFileProductId { get; set; }

        public int DigitalFileId { get; set; }

        public int ProductId { get; set; }

        public bool IsActive { get; set; }

        public DateTime CreatedAt { get; set; }

    }
}
