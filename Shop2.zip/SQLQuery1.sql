﻿CREATE TABLE [dbo].[Users] (
    [UserId]           INT          IDENTITY (1, 1) NOT NULL,
    [FirstName]    VARCHAR (50) NULL,
    [LastName]     VARCHAR (50) NULL,
    [EmailAddress] VARCHAR (50) NULL,
    [Username]     VARCHAR (50) NULL,
    [Password]     VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([UserId] ASC)
);

go

CREATE TABLE [dbo].[UserRoles] (
    [UserId] INT NOT NULL,
    [RoleId] INT NOT NULL,
    PRIMARY KEY CLUSTERED ([RoleId] ASC, [UserId] ASC)
);

go

CREATE TABLE [dbo].[Sidebars] (
    [SidebarId]   INT           NOT NULL,
    [Body] VARCHAR (MAX) NULL,
    PRIMARY KEY CLUSTERED ([sidebarId] ASC)
);

go

CREATE TABLE [dbo].[Roles] (
    [RoleId]   INT          IDENTITY (1, 1) NOT NULL,
    [Name] VARCHAR (50) NULL,
    PRIMARY KEY CLUSTERED ([RoleId] ASC)
);

go

CREATE TABLE [dbo].[Products] (
    [ProductId]           INT             IDENTITY (1, 1) NOT NULL,
    [ProductName]         VARCHAR (50)    NULL,
    [Slug]         VARCHAR (50)    NULL,
    [Description]  VARCHAR (MAX)   NULL,
    [Price]        NUMERIC (18, 2) NULL,
    [CategoryName] VARCHAR (50)    NULL,
    [CategoryId]   INT             NULL,
    [ImageName]    VARCHAR (100)   NULL,
    PRIMARY KEY CLUSTERED ([ProductId] ASC)
);

go

CREATE TABLE [dbo].[Pages] (
    [PageId]         INT           IDENTITY (1, 1) NOT NULL,
    [Title]      VARCHAR (50)  NULL,
    [Slug]       VARCHAR (50)  NULL,
    [Body]       VARCHAR (MAX) NULL,
    [Sorting]    INT           NULL,
    [HasSideBar] BIT           NULL,
    PRIMARY KEY CLUSTERED ([PageId] ASC)
);

go

CREATE TABLE [dbo].[Orders] (
    [OrderId]   INT           IDENTITY (1, 1) NOT NULL,
    [UserId]    INT           NULL,
    [CreatedAt] DATETIME2 (7) NULL,
    PRIMARY KEY CLUSTERED ([OrderId] ASC)
);

go

CREATE TABLE [dbo].[OrderDetails] (
    [OrderDetailId]        INT IDENTITY (1, 1) NOT NULL,
    [UserId]    INT NULL,
    [ProductId] INT NULL,
    [Quantity]  INT NULL,
    [OrderId]   INT NULL,
    PRIMARY KEY CLUSTERED ([OrderDetailsId] ASC)
);

go 

CREATE TABLE [dbo].[Categories] (
    [CategoryId]      INT          IDENTITY (1, 1) NOT NULL,
    [CategoryName]    VARCHAR (50) NULL,
    [Slug]    VARCHAR (50) NULL,
    [Sorting] INT          NULL,
    PRIMARY KEY CLUSTERED ([CategoryId] ASC)
);

go

	