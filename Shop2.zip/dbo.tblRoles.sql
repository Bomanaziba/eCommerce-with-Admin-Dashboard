﻿USE [AlphaXStore]
GO

/****** Object: Table [dbo].[tblRoles] Script Date: 8/5/2018 2:25:59 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblRoles] (
    [Id]        INT           IDENTITY (1, 1) NOT NULL,
    [Name]      VARCHAR (50)  NULL,
    [IsActive]  BIT           NULL,
    [CreatedAt] DATETIME2 (7) NULL
);


