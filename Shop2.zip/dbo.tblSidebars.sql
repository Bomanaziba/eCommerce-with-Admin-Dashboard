﻿USE [AlphaXStore]
GO

/****** Object: Table [dbo].[tblSidebars] Script Date: 8/5/2018 2:26:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblSidebars] (
    [Id]        INT           NOT NULL,
    [Body]      VARCHAR (MAX) NULL,
    [IsActive]  BIT           NULL,
    [CreatedAt] DATETIME2 (7) NULL
);


