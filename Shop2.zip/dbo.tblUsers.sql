﻿USE [AlphaXStore]
GO

/****** Object: Table [dbo].[tblUsers] Script Date: 8/5/2018 2:27:23 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblUsers] (
    [Id]           INT           IDENTITY (1, 1) NOT NULL,
    [FirstName]    VARCHAR (50)  NULL,
    [LastName]     VARCHAR (50)  NULL,
    [EmailAddress] VARCHAR (50)  NULL,
    [Username]     VARCHAR (50)  NULL,
    [Password]     VARCHAR (50)  NULL,
    [IsActive]     BIT           NULL,
    [CreatedAt]    DATETIME2 (7) NULL
);


