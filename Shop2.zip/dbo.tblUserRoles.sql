﻿USE [AlphaXStore]
GO

/****** Object: Table [dbo].[tblUserRoles] Script Date: 8/5/2018 2:27:07 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblUserRoles] (
    [UserId]    INT           NOT NULL,
    [RoleId]    INT           NOT NULL,
    [IsActive]  BIT           NULL,
    [CreatedAt] DATETIME2 (7) NULL
);


