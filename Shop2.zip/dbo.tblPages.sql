﻿USE [AlphaXStore]
GO

/****** Object: Table [dbo].[tblPages] Script Date: 8/5/2018 2:25:04 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblPages] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [Title]      VARCHAR (50)  NULL,
    [Slug]       VARCHAR (50)  NULL,
    [Body]       VARCHAR (MAX) NULL,
    [Sorting]    INT           NULL,
    [HasSideBar] BIT           NULL,
    [IsActive]   BIT           NULL,
    [CreatedAt]  DATETIME2 (7) NULL
);


