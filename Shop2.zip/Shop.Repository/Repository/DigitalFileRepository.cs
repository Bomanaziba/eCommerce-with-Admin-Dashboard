﻿using Shop.Domain.Model;
using Shop.Repository.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Repository.Repository
{
    public class DigitalFileRepository
    {

        public DigitalFile GetDigitalFileDetail(int digitalFileId)
        {
            try
            {
                using (EFDbContext dbContext = new EFDbContext())
                {
                    var aRecord = dbContext.DigitalFiles.Find(digitalFileId);

                    return aRecord;
                }
            }
            catch (Exception e)
            {
                throw new ApplicationException("Repository GetDigitalFileDetail", e);
            }
        }

        public List<DigitalFileProducts> GetDigitalFileList(int productId)
        {
            try
            {
                using (EFDbContext dbContext = new EFDbContext())
                {
                    var list = dbContext.DigtalFileProducts.Where(p => p.ProductId == productId).ToList();

                    return list;
                }
            }
            catch (Exception e)
            {
                throw new ArgumentNullException("GetDigitalFileList", e);
            }
        }

        public string SaveDigitalFile(int digitalFileTypeId, string fileName, string fileExtension, string contentType, byte[] theContent, out int digitalFileId)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentNullException(nameof(fileName));
            }

            if (string.IsNullOrEmpty(contentType))
            {
                throw new ArgumentNullException(nameof(contentType));
            }

            if (theContent == null)
            {
                throw new ArgumentNullException(nameof(theContent));
            }

            var result = string.Empty;
            digitalFileId = 0;

            var newRecord = new DigitalFile
            {
                TheDigitalFile = theContent,
                FileExtension = fileExtension,
                FileName = fileName,
                ContentType = contentType,
                DigitalTypeId = digitalFileTypeId,
                IsActive = true,
                DateCreated = DateTime.Now
            };

            try
            {
                using (EFDbContext dbContext = new EFDbContext())
                {
                    dbContext.DigitalFiles.Add(newRecord);
                    dbContext.SaveChanges();
                }
            }
            catch (Exception e)
            {
                result = string.Format("SaveDigitalFile - {0} , {1}", e.Message,
                    e.InnerException != null ? e.InnerException.Message : "");
            }

            digitalFileId = newRecord.DigitalFileId;
            return result;
        }
    }
}
