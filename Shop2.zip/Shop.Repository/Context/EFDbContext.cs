﻿using Shop.Domain.Model;
using System.Data.Entity;
using System.Linq;

namespace Shop.Repository.Context
{
    public class EFDbContext : DbContext
    {
        /// <summary>
        /// Gets or sets the categories.
        /// </summary>
        /// <value>
        /// The categories.
        /// </value>
        public DbSet<CategoryDTO> Categories { get; set; }
        /// <summary>
        /// Gets or sets the orders.
        /// </summary>
        /// <value>
        /// The orders.
        /// </value>
        public DbSet<OrderDTO> Orders { get; set; }
        /// <summary>
        /// Gets or sets the order details.
        /// </summary>
        /// <value>
        /// The order details.
        /// </value>
        public DbSet<OrderDetailsDTO> OrderDetails { get; set; }
        /// <summary>
        /// Gets or sets the pages.
        /// </summary>
        /// <value>
        /// The pages.
        /// </value>
        public DbSet<PageDTO> Pages { get; set; }
        /// <summary>
        /// Gets or sets the products.
        /// </summary>
        /// <value>
        /// The products.
        /// </value>
        public DbSet<ProductDTO> Products { get; set; }
        /// <summary>
        /// Gets or sets the roles.
        /// </summary>
        /// <value>
        /// The roles.
        /// </value>
        public DbSet<RoleDTO> Roles { get; set; }
        /// <summary>
        /// Gets or sets the sidebars.
        /// </summary>
        /// <value>
        /// The sidebars.
        /// </value>
        public DbSet<SidebarDTO> Sidebars { get; set; }
        /// <summary>
        /// Gets or sets the users.
        /// </summary>
        /// <value>
        /// The users.
        /// </value>
        public DbSet<UserDTO> Users { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public DbSet<UserRoleDTO> UserRoles { get; set; }
        /// <summary>
        /// Gets or sets the digital files.
        /// </summary>
        /// <value>
        /// The digital files.
        /// </value>
        public DbSet<DigitalFile> DigitalFiles { get; set; }

        public DbSet<DigitalFileProducts> DigtalFileProducts {get; set;}
        

        public void AddUser(UserDTO user)
        {
            Users.Add(user);
            SaveChanges();
        }

        public UserDTO GetUser(string userName)
        {
            var user = Users.SingleOrDefault(u => u.UserName == userName);
            return user;
        }

        public UserDTO GetUser(string userName, string password)
        {
            var user = Users.SingleOrDefault(u => u.UserName == userName && u.Password == password);
            return user;
        }

        public void AddUserRole(UserRoleDTO userRole)
        {
            var roleEntry = UserRoles.SingleOrDefault(r => r.UserId == userRole.UserId);

            if (roleEntry != null)
            {
                UserRoles.Remove(roleEntry);
                SaveChanges();
            }

            UserRoles.Add(userRole);
            SaveChanges();
        }

    }
}
