﻿using Shop.Domain.Model;
using Shop.Domain.ViewModel.Pages;
using Shop.Repository.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shop.Areas.Admin.Controllers
{
    [Authorize(Roles = "Admin")]
    public class PagesController : Controller
    {
        // GET: Admin/Pages
        public ActionResult Index()
        {
            //Declare List of Pages
            List<PageVM> pageList;


            using (EFDbContext context = new EFDbContext())
            {
                //Init the list
                pageList = context.Pages.ToArray().OrderBy(x => x.Sorting).Select(x => new PageVM(x)).ToList();
            }
            //Return view with list
            return View(pageList);
        }

        //GET: Admin/Pages/AddPage
        [HttpGet]
        public ActionResult AddPage()
        {
            return View();
        }

        //POST: Admin/Pages/AddPage
        [HttpPost]
        public ActionResult AddPage(PageVM model)
        {
            //Check model state
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            using (EFDbContext context = new EFDbContext())
            {
                //Declare slug
                string slug;
                //Init pageDTO
                PageDTO dto = new PageDTO();
                //DTO title
                dto.Title = model.Title;
                //Check for and set slug if need be
                if (string.IsNullOrWhiteSpace(model.Slug))
                {
                    slug = model.Title.Replace(" ", "-").ToLower();
                }
                else
                {
                    slug = model.Slug.Replace(" ", "-").ToLower();
                }
                //Make sure title and slug are unique
                if (context.Pages.Any(x => x.Title == model.Title) || context.Pages.Any(x => x.Slug == slug))
                {
                    ModelState.AddModelError("", "That title of slug already exist");
                    return View(model);
                }
                //DTO the rest
                dto.Slug = slug;
                dto.Body = model.Body;
                dto.HasSideBar = model.HasSideBar;
                dto.Sorting = 100;
                //Save DTO
                context.Pages.Add(dto);
                context.SaveChanges();
            }
            //Set Temp Data Message
            TempData["SM"] = "You have added a new Page!";

            //Redirect
            return RedirectToAction("AddPage");
        }

        //GET: Admin/Pages/EditPage/id
        [HttpGet]
        public ActionResult EditPage(int id)
        {
            //Declare pageVM
            PageVM model;

            using (EFDbContext context = new EFDbContext())
            {
                //Get the page
                PageDTO dto = context.Pages.Find(id);
                //Configure page exists
                if (dto == null)
                {
                    return Content("The page does not exist.");
                }

                //Init pageVM
                model = new PageVM(dto);


                //Return view with model
                return View(model);
            }
        }

        //POST: Admin/Pages/EditPage/id
        [HttpPost]
        public ActionResult EditPage(PageVM model)
        {
            //Check model state
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            using (EFDbContext context = new EFDbContext())
            {
                //Get page id
                int id = model.Id;
                //Init slug
                string slug = "home";

                //Get the page
                PageDTO dto = context.Pages.Find(id);

                //DTO the title
                dto.Title = model.Title;

                //Check for slug and set it if need be
                if (model.Slug != "home")
                {
                    if (string.IsNullOrWhiteSpace(model.Slug))
                    {
                        slug = model.Title.Replace(" ", "-").ToLower();
                    }
                    else
                    {
                        slug = model.Slug.Replace(" ", "-").ToLower();
                    }
                }
                //Make sure title and slug are unique
                if (context.Pages.Where(x => x.Id != id).Any(x => x.Title == model.Title) ||
                    context.Pages.Where(x => x.Id != id).Any(x => x.Slug == slug))
                {
                    ModelState.AddModelError("", "The title or slug already exits.");
                    return View(model);
                }
                //DTO the rest
                dto.Slug = slug;
                dto.Body = model.Body;
                dto.HasSideBar = model.HasSideBar;

                //Save the DTO
                context.SaveChanges();
            };

            //Set TempData message
            TempData["SM"] = "You have elected the page";
            //Redirect 
            return RedirectToAction("EditPage");

        }

        //GET: Admin/Pages/PageDetails/id
        public ActionResult PageDetails(int id)
        {
            //Declare PageVM
            PageVM model;

            using (EFDbContext context = new EFDbContext())
            {
                //Get the page 
                PageDTO dTO = context.Pages.Find(id);
                //Configure page exists
                if (dTO == null)
                {
                    return Content("The page does not exist.");
                }
                //Init PageVM
                model = new PageVM(dTO);
            }

            //Return view with model
            return View(model);
        }

        //GET: Admin/Pages/EditPage/id
        [HttpGet]
        public ActionResult DeletePage(int id)
        {
            using (EFDbContext context = new EFDbContext())
            {
                //Get the page
                PageDTO dTO = context.Pages.Find(id);
                //Remove the page 
                context.Pages.Remove(dTO);
                //Save
                context.SaveChanges();
            }
            //Redirect
            return RedirectToAction("Index");
        }

        //Post: Admin/Pages/ReorderPages
        [HttpPost]
        public void ReorderPages(int[] id)
        {
            using (EFDbContext context = new EFDbContext())
            {
                //Set initial count 
                int count = 1;

                //Declare PageDTO
                PageDTO dTO;

                //Set sorting for each page
                foreach (var pageId in id)
                {
                    dTO = context.Pages.Find(pageId);
                    dTO.Sorting = count;

                    context.SaveChanges();

                    count++;
                }
            }
        }

        //GET: Admin/Pages/EditSidebar
        [HttpGet]
        public ActionResult EditSidebar()
        {
            //Declare model
            SidebarVM model;

            using (EFDbContext context = new EFDbContext())
            {
                //Get the DTO 
                SidebarDTO dto = context.Sidebars.Find(1);

                //Init model
                model = new SidebarVM(dto);
            }

            //Return view wth model
            return View(model);
        }

        //Post: Admin/Pages/EditSidebar
        [HttpPost]
        public ActionResult EditSidebar(SidebarVM model)
        {
            using (EFDbContext context = new EFDbContext())
            {
                //Get the DTO 
                SidebarDTO dto = context.Sidebars.Find(1);

                //DTO the body
                dto.Body = model.Body;

                //Save
                context.SaveChanges();

                //Set TempData
                TempData["SM"] = "You have editted the sidebar";

                //Redirect
                return RedirectToAction("EditSidebar");
            }
        }
    }
}