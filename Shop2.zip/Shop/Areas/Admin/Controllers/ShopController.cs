﻿using PagedList;
using Shop.Areas.Admin.Models.ViewModel;
using Shop.Domain.Model;
using Shop.Domain.ViewModel.Shop;
using Shop.FileExtension;
using Shop.Interface;
using Shop.Repository.Context;
using Shop.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace Shop.Areas.Admin.Controllers
{
    public class ShopController : Controller
    {
        // GET: Admin/Shop/Categories
        public ActionResult Categories()
        {
            //Declare a list of models
            List<CategoryVM> categoryVMList;

            using (EFDbContext context = new EFDbContext())
            {
                //Init the list
                categoryVMList = context.Categories
                    .ToArray()
                    .OrderBy(x => x.Id)
                    .Select(x => new CategoryVM(x))
                    .ToList();
            }
            //Return view with a list
            return View(categoryVMList);
        }

        // POST: Admin/Shop/AddNewCategory
        [HttpPost]
        public string AddNewCategory(string catName)
        {
            //Declare id
            string id;

            using (EFDbContext context = new EFDbContext())
            {
                //Check that the category name is unique
                if (context.Categories.Any(x => x.Name == catName))
                    return "titletaken";

                //Init DTO
                CategoryDTO dto = new CategoryDTO();

                //Addto DTO
                dto.Name = catName;
                dto.Slug = catName.Replace(" ", "-").ToLower();
                dto.Sorting = 100;
                dto.CreatedAt = DateTime.UtcNow;

                //Save DTO
                context.Categories.Add(dto);
                context.SaveChanges();

                //Get the id
                id = dto.Id.ToString();
            }

            //Return id
            return id;
        }

        //POST: Admin/Shop/ReorderCategories
        [HttpPost]
        public void ReorderCategories(int[] id)
        {
            using (EFDbContext context = new EFDbContext())
            {
                //Set initial count 
                int count = 1;

                //Declare CategoryDTO
                CategoryDTO dTO;

                //Set sorting for each category
                foreach (var catId in id)
                {
                    dTO = context.Categories.Find(catId);
                    dTO.Sorting = count;

                    context.SaveChanges();

                    count++;
                }
            }
        }

        // GET: Admin/Shop/DeleteCategory/id
        public ActionResult DeleteCategory(int id)
        {
            using (EFDbContext context = new EFDbContext())
            {
                //Get the category
                CategoryDTO dto = context.Categories.Find(id);

                //Remove the category
                context.Categories.Remove(dto);

                //Save
                context.SaveChanges();
            }

            //Redirect
            return RedirectToAction("Categories");
        }

        //POST: Admin/Shop/RenameCategories
        [HttpPost]
        public string RenameCategory(string newCatName, int id)
        {
            using (EFDbContext context = new EFDbContext())
            {
                //Check category name is unique
                if (context.Categories.Any(x => x.Name == newCatName))
                    return "titletaken";

                //Get DTO
                CategoryDTO dto = context.Categories.Find(id);

                //Edit DTO
                dto.Name = newCatName;
                dto.Slug = newCatName.Replace(" ", "-").ToLower();

                //Save
                context.SaveChanges();
            }

            //Return 
            return "Ok";
        }

        // GET: Admin/Shop/AddProduct
        public ActionResult AddProduct()
        {
            //Init model
            ProductVM model = new ProductVM();

            //Add select list of category to model
            using (EFDbContext context = new EFDbContext())
            {
                model.Categories = new SelectList(context.Categories.ToList(), "Id", "Name");
            }
            //Return view with model
            return View(model);
        }

        // POST: Admin/Shop/AddProduct
        [HttpPost]
        public ActionResult AddProduct(ProductVM model, HttpPostedFileBase file)
        {
            //Check modell state 
            if (!ModelState.IsValid)
            {
                using (EFDbContext context = new EFDbContext())
                {
                    model.Categories = new SelectList(context.Categories.ToList(), "Id", "Name");
                    return View(model);
                }
            }

            //Make sure product name us unique
            using (EFDbContext context = new EFDbContext())
            {
                if (context.Products.Any(x => x.Name == model.Name))
                {
                    model.Categories = new SelectList(context.Categories.ToList(), "Id", "Name");
                    ModelState.AddModelError("", "That product name us taken!");
                    return View(model);
                }
            }

            //Declare product id
            int id;

            //Declcare digital file id
            int digitalFileId = -1;

            DigitalFileService digtialFileService = new DigitalFileService();

            //Save to DigitalFile table then get out the digitalFileId
            var saveImage = digtialFileService.SaveFile(FileType.Image, file, out digitalFileId);
        
            //Init and save productDTO
            using (EFDbContext context = new EFDbContext())
            {
                ProductDTO product = new ProductDTO();

                product.Name = model.Name;
                product.Slug = model.Slug;
                product.Description = model.Description;
                product.Price = model.Price;
                product.CategoryId = model.CategoryId;
                product.IsActive = true;
                product.CreatedAt = model.CreatedAt;

                CategoryDTO catDTO = context.Categories.FirstOrDefault(x => x.Id == model.CategoryId);
                product.CategoryName = catDTO.Name;

                context.Products.Add(product);
                context.SaveChanges();

                //Get the id
                id = product.Id;
            }


            if((id > 0) && (digitalFileId > 0))
            {
                using (EFDbContext context = new EFDbContext())
                {
                    DigitalFileProducts digitalFileProducts = new DigitalFileProducts();

                    digitalFileProducts.DigitalFileId = digitalFileId;
                    digitalFileProducts.ProductId = id;
                    digitalFileProducts.IsActive = true;
                    digitalFileProducts.CreatedAt = DateTime.UtcNow;

                    context.DigtalFileProducts.Add(digitalFileProducts);
                    context.SaveChanges();
                }
            }


            //Set TempData message
            TempData["SM"] = "You have added a product!";

            #region Upload Image

            //Create the necessary directories
            var originalDirectory = new DirectoryInfo(string.Format("{0}Images\\Uploads", Server.MapPath(@"\")));

            var pathString1 = Path.Combine(originalDirectory.ToString(), "Products");
            var pathString2 = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString());
            var pathString3 = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString(), "\\Thumbs");
            var pathString4 = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString(), "\\Gallery");
            var pathString5 = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString(), "\\Gallery\\Thumbs");

            if (!Directory.Exists(pathString1))
                Directory.CreateDirectory(pathString1);
            if (!Directory.Exists(pathString2))
                Directory.CreateDirectory(pathString2);
            if (!Directory.Exists(pathString3))
                Directory.CreateDirectory(pathString3);
            if (!Directory.Exists(pathString4))
                Directory.CreateDirectory(pathString4);
            if (!Directory.Exists(pathString5))
                Directory.CreateDirectory(pathString5);

            //Check id a file was uploaded
            if (file != null && file.ContentLength > 0)
            {
                //Get file extension
                string ext = file.ContentType.ToLower();

                //Verify extension
                if (ext != "image/jpg" &&
                    ext != "image/jpeg" &&
                    ext != "image/pjeg" &&
                    ext != "image/gif" &&
                    ext != "image/x-png" &&
                    ext != "image/png")
                {
                    using (EFDbContext context = new EFDbContext())
                    {
                        model.Categories = new SelectList(context.Categories.ToList(), "Id", "Name");
                        ModelState.AddModelError("", "The image was not uploaded - wrong image extension.");
                        return View(model);
                    }
                }

                //Init image name
                string imageNAme = file.FileName;

                //Save image name to DTO
                using (EFDbContext context = new EFDbContext())
                {
                    ProductDTO dto = context.Products.Find(id);
                    dto.ImageName = imageNAme;

                    context.SaveChanges();
                }

                //Set original and thumb image paths
                var path = string.Format("{0}\\{1}", pathString2, imageNAme);
                var path2 = string.Format("{0}\\{1}", pathString3, imageNAme);

                //Save original
                file.SaveAs(path);

                //Create and save thumb
                WebImage img = new WebImage(file.InputStream);
                img.Resize(200, 200);
                img.Save(path2);
            }
            #endregion

            //Redirect
            return RedirectToAction("AddProduct");
        }

        //GET: Admin/Shop/AddProduct
        public ActionResult Products(int? page, int? catId)
        {
            //Declare a list of prductVM
            List<ProductVM> listOfProductVM;

            //Set page number 
            var pageNumber = page ?? 1;

            using (EFDbContext context = new EFDbContext())
            {
                //Init the list 
                listOfProductVM = context.Products.ToArray()
                    .Where(x => catId == null || catId == 0 || x.CategoryId == catId)
                    .Select(x => new ProductVM(x))
                    .ToList();
                //Populate categories selecct list 
                ViewBag.Categories = new SelectList(context.Categories.ToList(), "Id", "Name");

                //Set selected category
                ViewBag.SelectedCat = catId.ToString();
            }

            //Set pagination
            var onePageOfProudcts = listOfProductVM.ToPagedList(pageNumber, 3);
            ViewBag.OnePageOfProducts = onePageOfProudcts;

            //Return view with list
            return View();
        }

        //GET: Admin/Shop/EditProduct/id
        [HttpGet]
        public ActionResult EditProduct(int id)
        {
            //Declare productVM
            ProductVM model;

            using (EFDbContext context = new EFDbContext())
            {
                //Get the product 
                ProductDTO dto = context.Products.Find(id);

                //Make sure product exists
                if (dto == null)
                {
                    return Content("That product does not exist.");
                }

                //Init model
                model = new ProductVM(dto);

                //Make a select list 
                model.Categories = new SelectList(context.Categories.ToList(), "Id", "Name");


                //Get all gallery images
                model.GalleryImages = Directory.EnumerateFiles(Server.MapPath("~/images/Uploads/Products/" + id + "/Gallery/Thumbs"))
                                               .Select(fn => Path.GetFileName(fn));
            }
            //Return view with model
            return View(model);
        }

        //POST: Admin/Shop/EditProduct/id
        [HttpPost]
        public ActionResult EditProduct(ProductVM model, HttpPostedFileBase file)
        {
            //Get product id
            int id = model.Id;
            //Populate categories select list and gallery
            using (EFDbContext context = new EFDbContext())
            {
                model.Categories = new SelectList(context.Categories.ToList(), "Id", "Name");
            }
            model.GalleryImages = Directory.EnumerateFiles(Server.MapPath("~/images/Uploads/Products/" + id + "/Gallery"))
                                               .Select(fn => Path.GetFileName(fn));

            //Check model state 
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            //Make sure product name is unique
            using (EFDbContext context = new EFDbContext())
            {
                if (context.Products.Where(x => x.Id != id).Any(x => x.Name == model.Name))
                {
                    ModelState.AddModelError("", "That product name is taken!");
                    return View(model);
                }
            }

            //Update product
            using (EFDbContext context = new EFDbContext())
            {
                ProductDTO dto = context.Products.Find(id);

                dto.Name = model.Name;
                dto.Slug = model.Name.Replace(" ", "-").ToLower();
                dto.Description = model.Description;
                dto.Price = model.Price;
                dto.CategoryId = model.CategoryId;
                dto.ImageName = model.ImageName;

                CategoryDTO catDTO = context.Categories.FirstOrDefault(x => x.Id == model.CategoryId);
                dto.CategoryName = catDTO.Name;

                context.SaveChanges();
            }

            //Set TempData message
            TempData["SM"] = "You have edited the product!";

            #region Image Upload
            //Check for file upload 
            if (file != null && file.ContentLength > 0)
            {
                //Get extension
                string ext = file.ContentType.ToLower();

                //Verify extension
                if (ext != "image/jpg" &&
                   ext != "image/jpeg" &&
                   ext != "image/pjpeg" &&
                   ext != "image/x-png" &&
                   ext != "image/png")
                {
                    using (EFDbContext context = new EFDbContext())
                    {
                        ModelState.AddModelError("", "The image was not uploaded - wrong image extension.");
                        return View(model);
                    }
                }

                //Set upload directory path
                var originalDirectory = new DirectoryInfo(string.Format("{0}images\\Uploads", Server.MapPath(@"\")));

                var pathString1 = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString());
                var pathString2 = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString() + "\\Gallery" + "\\Thumbs");

                //Delete files drom directories

                DirectoryInfo di1 = new DirectoryInfo(pathString1);
                DirectoryInfo di2 = new DirectoryInfo(pathString2);

                foreach (FileInfo file2 in di1.GetFiles())
                    file2.Delete();
                foreach (FileInfo file3 in di2.GetFiles())
                    file3.Delete();

                //Saveimage name
                string imageName = file.FileName;

                using (EFDbContext context = new EFDbContext())
                {
                    ProductDTO dto = context.Products.Find(id);
                    dto.ImageName = imageName;

                    context.SaveChanges();
                }

                //Save original and thumb images
                var path = string.Format("{0}\\{1}", pathString1, imageName);
                var path2 = string.Format("{0}\\{1}", pathString2, imageName);

                file.SaveAs(path);

                //Create and Save thumb
                WebImage img = new WebImage(file.InputStream);
                img.Resize(200, 200);
                img.Save(path2);
            }

            #endregion

            return RedirectToAction("EditProduct");
        }

        //GET: Admin/Shop/DeleteProduct/id
        public ActionResult DeleteProduct(int id)
        {
            //Delete product from DB
            using (EFDbContext context = new EFDbContext())
            {
                ProductDTO dto = context.Products.Find(id);
                context.Products.Remove(dto);

                context.SaveChanges();
            }

            //Delete product folder
            var originalDirectory = new DirectoryInfo(string.Format("{0}images\\Uploads", Server.MapPath(@"\")));
            string pathString = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString());

            if (Directory.Exists(pathString))
                Directory.Delete(pathString, true);

            //Redirect 
            return RedirectToAction("Products");
        }

        //POST: Admin/Shop/SaveGalleryImages/id
        [HttpPost]
        public void SaveGalleryImages(int id)
        {
            //Loop through file
            foreach (string fileName in Request.Files)
            {

                //init the file
                HttpPostedFileBase file = Request.Files[fileName];

                //Check it's not null
                if (file != null && file.ContentLength > 0)
                {
                    //Set directory paths
                    var originalDirectory = new DirectoryInfo(string.Format("{0}images\\Uploads", Server.MapPath(@"\")));

                    string pathString1 = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString() + "\\Gallery");
                    string pathString2 = Path.Combine(originalDirectory.ToString(), "Products\\" + id.ToString() + "\\Gallery\\Thumbs");

                    //Set image paths
                    var path = string.Format("{0}\\{1}", pathString1, file.FileName);
                    var path2 = string.Format("{0}\\{1}", pathString2, file.FileName);


                    //Save original and thumb
                    file.SaveAs(path);
                    WebImage img = new WebImage(file.InputStream);
                    img.Resize(200, 200);
                    img.Save(path2);

                }
            }

        }

        //POST: Admin/Shop/DeleteImage/id
        [HttpPost]
        public void DeleteImage(int id, string imageName)
        {
            string fullPath1 = Request.MapPath("~/image/Upload/Products/" + id.ToString() + "/Gallery/" + imageName);
            string fullPath2 = Request.MapPath("~/image/Upload/Products/" + id.ToString() + "/Gallery/Thumbs/" + imageName);

            if (System.IO.File.Exists(fullPath1))
                System.IO.File.Delete(fullPath1);

            if (System.IO.File.Exists(fullPath2))
                System.IO.File.Delete(fullPath2);
        }

        //GET: Admin/Shop/Orders
        public ActionResult Orders()
        {
            //Init list of ordervm
            List<OrdersForAdminVM> ordersForAdmin = new List<OrdersForAdminVM>();

            using (EFDbContext context = new EFDbContext())
            {
                //Init list of ordervm
                List<OrderVM> orders = context.Orders.ToArray().Select(x => new OrderVM(x)).ToList();

                //loop through list of ordervm
                foreach (var order in orders)
                {
                    //init product dict 
                    Dictionary<string, int> productsAndQty = new Dictionary<string, int>();

                    //Declare total
                    decimal total = 0m;

                    //Init list of orderdetialsdto
                    List<OrderDetailsDTO> orderDetailsList = context.OrderDetails.Where(x => x.OrderId == order.OrderId).ToList();

                    //Get username 
                    UserDTO user = context.Users.Where(x => x.UserId == order.UserId).FirstOrDefault();
                    string username = user.UserName;


                    //loop through list of orderdetailsdto
                    foreach (var orderDetails in orderDetailsList)
                    {
                        //Get product
                        ProductDTO product = context.Products.Where(x => x.Id == orderDetails.ProductId).FirstOrDefault();

                        //Get product price
                        decimal price = product.Price;

                        //Get product name
                        string productName = product.Name;

                        //Add to product dict 
                        productsAndQty.Add(productName, orderDetails.Quantity);

                        //Get total 
                        total += orderDetails.Quantity * price;
                    }

                    //Add to ordersForAdminVM list
                    ordersForAdmin.Add(new OrdersForAdminVM()
                    {
                        OrderNumber = order.OrderId,
                        Username = username,
                        Total = total,
                        ProductsAndQty = productsAndQty,
                        CreatedAt = order.CreatedAt

                    });
                }
            }
            //Return view with ordersforadminvm list
            return View(ordersForAdmin);
        }

    }
}