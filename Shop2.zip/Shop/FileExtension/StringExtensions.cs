﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shop.FileExtension
{
    public static class StringExtensions
    {
        public static string FileExtension(this string fileName)
        {
            if (fileName == null)
            {
                throw new ArgumentException("fileName");
            }

            var result = fileName.Substring(fileName.LastIndexOf('.'));

            return result;
        }
    }
}