﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shop.FileExtension
{
    public struct FileType
    {
        public const int Image = 1;

        public const int Pdf = 2;

        public const int WordDocument = 3;

        public const int Unknown = 99;
    }
}