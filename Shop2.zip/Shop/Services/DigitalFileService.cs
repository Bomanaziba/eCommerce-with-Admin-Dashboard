﻿using Shop.Domain.Model;
using Shop.FileExtension;
using Shop.Repository.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Shop.Services
{
    public class DigitalFileService
    {



        DigitalFileRepository digitalFileRepository = new DigitalFileRepository();


       

        public string SaveFile(int digitalFileTypeId, HttpPostedFileBase productImage, out int digitalFileId)
        {
            digitalFileId = 0;
            var processingMessage = string.Empty;

            if ((productImage == null) || (productImage.ContentLength < 1))
            {
                return processingMessage;
            }

            byte[] theContent;

            using (Stream inputStream = productImage.InputStream)
            {
                MemoryStream memoryStream = inputStream as MemoryStream;
                if (memoryStream == null)
                {
                    memoryStream = new MemoryStream();
                    inputStream.CopyTo(memoryStream);
                }
                theContent = memoryStream.ToArray();
            }

            var fileName = productImage.FileName;
            var contentType = productImage.ContentType;
            var fileExtension = fileName.FileExtension();

            processingMessage = this.digitalFileRepository.SaveDigitalFile(digitalFileTypeId, fileName, fileExtension, contentType, theContent, out digitalFileId);

            return processingMessage;
        }
    }
}