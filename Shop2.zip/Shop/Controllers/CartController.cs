﻿using Shop.Domain.Model;
using Shop.Domain.ViewModel.Cart;
using Shop.Repository.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;

namespace Shop.Controllers
{
    public class CartController : Controller
    {
        // GET: Cart
        public ActionResult Index()
        {
            //Init the cart list
            var cart = Session["cart"] as List<CartVM> ?? new List<CartVM>();

            //Check if cart is empty
            if (cart.Count == 0 || Session["cart"] == null)
            {
                ViewBag.Message = "Your cart is empty.";
                return View();
            }

            //Calculate total and save to Viewbag
            decimal total = 0m;

            foreach (var item in cart)
            {
                total += item.Total;
            }

            ViewBag.GrandTotal = total;

            //Return view with model
            return View(cart);
        }

        public ActionResult CartPartial()
        {
            //Init CartVM
            CartVM model = new CartVM();

            //Init Quantity
            int qty = 0;

            //Init price
            decimal price = 0m;

            //Check for cart session
            if (Session["cart"] != null)
            {
                //Get total qty and price
                var list = (List<CartVM>)Session["cart"];

                foreach (var item in list)
                {
                    qty += item.Quantity;
                    price += item.Quantity * item.Price;
                }

                model.Quantity = qty;
                model.Price = price;

            }
            else
            {
                //Or set qty and price to 0
                model.Quantity = 0;
                model.Price = 0m;
            }

            //Return partial view with model
            return PartialView(model);
        }

        public ActionResult AddToCartPartial(int id)
        {
            //Init CartVM list
            List<CartVM> cart = Session["cart"] as List<CartVM> ?? new List<CartVM>();

            //Init CartVM
            CartVM model = new CartVM();

            using (EFDbContext context = new EFDbContext())
            {
                //Get the product
                ProductDTO product = context.Products.Find(id);

                //Check if the product is already in cart
                var productInCart = cart.FirstOrDefault(x => x.Id == id);

                //If not, add new 
                if (productInCart == null)
                {
                    cart.Add(new CartVM()
                    {
                        Id = product.Id,
                        Name = product.Name,
                        Quantity = 1,
                        Price = product.Price,
                        //Image = product.ImageMimeType
                    });
                }
                else
                {
                    //if it is, increment
                    productInCart.Quantity++;
                }
            }

            //Get total qty and price to model
            int qty = 0;
            decimal price = 0m;

            foreach (var item in cart)
            {
                qty += item.Quantity;
                price += item.Quantity * item.Price;
            }

            model.Quantity = qty;
            model.Price = price;

            //Save cart back to session
            Session["cart"] = cart;

            //Return partial view with model 
            return PartialView(model);
        }

        //GET: /Cart/IncrementProduct
        public ActionResult IncrementProduct(int productId)
        {
            //Init cart list
            List<CartVM> cart = Session["cart"] as List<CartVM>;

            using (EFDbContext context = new EFDbContext())
            {
                //Get cartVM from list
                CartVM model = cart.FirstOrDefault(x => x.Id == productId);

                //Increment qty
                model.Quantity++;

                //Store needed data
                var result = new { qty = model.Quantity, price = model.Price };

                //Return json with data
                return Json(result, JsonRequestBehavior.AllowGet);
            }



        }

        //GET: /Cart/DecrementProduct
        public ActionResult DecrementProduct(int productId)
        {
            //Init cart 
            List<CartVM> cart = Session["cart"] as List<CartVM>;

            using (EFDbContext context = new EFDbContext())
            {
                //Get model from list 
                CartVM model = cart.FirstOrDefault(x => x.Id == productId);

                //Decrement qty
                if (model.Quantity > 1)
                {
                    model.Quantity--;
                }
                else
                {
                    model.Quantity = 0;
                    cart.Remove(model);
                }



                //Store needed data
                var result = new { qty = model.Quantity, price = model.Price };

                //Return json with data
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }

        //GET: /Cart/RemoveProduct
        public void RemoveProduct(int productId)
        {
            //Init cart list 
            List<CartVM> cart = Session["cart"] as List<CartVM>;

            using (EFDbContext context = new EFDbContext())
            {
                //Get product from list
                CartVM model = cart.FirstOrDefault(x => x.Id == productId);

                //remove model from list
                cart.Remove(model);
            }


        }

        //GET: /Cart/PaypalPartial
        public ActionResult PaypalPartial()
        {
            List<CartVM> cart = Session["cart"] as List<CartVM>;

            return PartialView(cart);
        }

        //POST: /Cart/PlaceOrder
        [HttpPost]
        public void PlaceOrder()
        {
            //Get cart list 
            List<CartVM> cart = Session["cart"] as List<CartVM>;

            //Get user id
            string username = User.Identity.Name;

            //Declare order id
            int orderId = 0;


            using (EFDbContext context = new EFDbContext())
            {
                //Init OrderDTO
                OrderDTO orderDTO = new OrderDTO();

                //Get user id
                var q = context.Users.FirstOrDefault(x => x.EmailAddress == username);
                int userId = q.UserId;

                //Add to OrderDTO and save
                //orderDTO.UserId = userId;
                orderDTO.CreatedAt = DateTime.Now;

                context.Orders.Add(orderDTO);

                context.SaveChanges();

                //Get inserted id 
                orderId = orderDTO.OrderId;

                //Init OrderDetailsDTO
                OrderDetailsDTO orderDetailsDTO = new OrderDetailsDTO();


                //Add to OrderDetailsDTO
                foreach (var item in cart)
                {
                    //orderDetailsDTO.OrderId = orderId;
                    //orderDetailsDTO.UserId = userId;
                    //orderDetailsDTO.ProductId = item.ProductId;
                    //orderDetailsDTO.Quantity = item.Quantity;

                    context.OrderDetails.Add(orderDetailsDTO);

                    context.SaveChanges();
                }
            }

            //Email admin
            var client = new SmtpClient("smtp.mailtrap.io", 2525)
            {
                Credentials = new NetworkCredential("52d8b13877e3e0", "9adfa94527eefb"),
                EnableSsl = true
            };
            client.Send("admin@example.com", "admin@example.com", "New Order", "You have a new order and other numbwe " + orderId);

            //reset session
            Session["cart"] = null;
        }
    }
}