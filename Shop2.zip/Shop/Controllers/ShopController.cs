﻿using Shop.Domain.Model;
using Shop.Repository.Context;
using Shop.Domain.ViewModel.Shop;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shop.Controllers
{
    public class ShopController : Controller
    {
        // GET: Shop
        public ActionResult Index()
        {

            //Declare a list of models
            List<ProductVM> productVMList;

            using (EFDbContext context = new EFDbContext())
            {
                //Init the list
                productVMList = context.Products
                    .ToArray()
                    .OrderBy(x => x.Name)
                    .Select(x => new ProductVM(x))
                    .ToList();
            }

            //Return view with a list
            return View("Index", productVMList);
        }

        public ActionResult CategoryMenuPartial()
        {
            //Declare list of CategoryVM
            List<CategoryVM> categoryVMList;

            //Init the list
            using (EFDbContext context = new EFDbContext())
            {
                categoryVMList = context.Categories.ToArray().OrderBy(x => x.Sorting).Select(x => new CategoryVM(x)).ToList();
            }
            //Return partial with list
            return PartialView(categoryVMList);
        }

        //GET: /shop/category/name
        public ActionResult Category(string name)
        {
            //Declare list of product
            List<ProductVM> productVMList;

            using (EFDbContext context = new EFDbContext())
            {
                //Get category id
                CategoryDTO categoryDTO = context.Categories.Where(x => x.Slug == name).FirstOrDefault();
                int catId = categoryDTO.Id;

                //Init the list
                productVMList = context.Products.ToArray().Where(x => x.CategoryId == catId).Select(x => new ProductVM(x)).ToList();

                //Get category name
                var productCat = context.Products.Where(x => x.CategoryId == catId).FirstOrDefault();
                ViewBag.CategoryName = productCat.CategoryName;

            }

            //return view with list
            return View(productVMList);
        }

        //GET: /shop/product-details/name
        [ActionName("product-details")]
        public ActionResult ProductDetails(string name)
        {
            //Declare the VM and DTO
            ProductVM model;
            ProductDTO dto;

            //Init product id
            int id = 0;

            using (EFDbContext context = new EFDbContext())
            {
                //Check if product exists
                if (!context.Products.Any(x => x.Name.Equals(name)))
                {
                    return RedirectToAction("Index", "Shop");
                }

                //Init productDTO 
                dto = context.Products.Where(x => x.Name == name).FirstOrDefault();

                //Get id
                id = dto.Id;

                //Init model
                model = new ProductVM(dto);
            }

            using (EFDbContext context = new EFDbContext())
            {
                DigitalFileRepository digitalFile 

            }

                //Get gallery images
                model.GalleryImages = Directory.EnumerateFiles(Server.MapPath("~/Images/Uploads/Products/" + id + "/Gallery/Thumbs"))
                                                   .Select(fn => Path.GetFileName(fn));
            //Return view with model
            return View("ProductDetails", model);
        }
    }
}