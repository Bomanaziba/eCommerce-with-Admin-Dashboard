﻿using Shop.Domain.Model;
using Shop.Domain.ViewModel.Pages;
using Shop.Repository.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shop.Controllers
{
    public class PagesController : Controller
    {
        // GET: Pages
        public ActionResult Index(string page = "")
        {
            //Get/Set page slug
            if (page == "")
                page = "home";
            //Declare model and DTO
            PageVM model;
            PageDTO dto;

            //check if page exists
            using (EFDbContext context = new EFDbContext())
            {
                if (!context.Pages.Any(x => x.Slug.Equals(page)))
                    return RedirectToAction("Index", new { page = "" });
            }

            //Get page DTO
            using (EFDbContext context = new EFDbContext())
            {
                dto = context.Pages.Where(x => x.Slug == page).FirstOrDefault();
            }

            //Set page title
            ViewBag.PageTitle = dto.Title;

            //Check for sidebar 
            if (dto.HasSideBar == true)
            {
                ViewBag.Sidebar = "Yes";
            }
            else
            {
                ViewBag.Sidebar = "No";
            }

            //init model
            model = new PageVM(dto);

            //Return View with model
            return View(model);
        }

        public ActionResult PagesMenuPartial()
        {
            //Declare a list of PageVM
            List<PageVM> pageVmList;

            //Get all pages except home
            using (EFDbContext context = new EFDbContext())
            {
                pageVmList = context.Pages.ToArray().OrderBy(x => x.Sorting).Where(x => x.Slug != "home").Select(x => new PageVM(x)).ToList();
            }

            //Return partial View with list
            return PartialView(pageVmList);
        }

        public ActionResult SidebarPartial()
        {
            //Declare model
            SidebarVM model;

            //inital model
            using (EFDbContext context = new EFDbContext())
            {
                SidebarDTO dto = context.Sidebars.Find(1);
                model = new SidebarVM(dto);
            }

            //Return partial view with model
            return PartialView(model);
        }
    }
}