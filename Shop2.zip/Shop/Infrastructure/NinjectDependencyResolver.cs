﻿using Ninject;
using Shop.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shop.Infrastructure
{
    public class NinjectDependencyResolver : IDependencyResolver
    {
        private IKernel kernel;

        public NinjectDependencyResolver(IKernel kernelParam)
        {
            kernel = kernelParam;
            AddBindings();
        }

        public object GetService(Type serviceType)
        {
            return kernel.TryGet(serviceType);
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            return kernel.GetAll(serviceType);
        }
        
        private void AddBindings()
        {
            //kernel.Bind<ICategoryRepository>().To<CategoryRepository>();
            //kernel.Bind<IProductRepository>().To<ProductRepository>();
            //kernel.Bind<IUserRepository>().To<UserRepository>();
            //kernel.Bind<IDigitalFileRepository>().To<DigitalFileRepository>();

            //kernel.Bind<ICategory>().To<Category>();
            //kernel.Bind<ICategoryViewModel>().To<CategoryViewModel>();
            //kernel.Bind<IOrder>().To<Order>();
            //kernel.Bind<IProduct>().To<Product>();
            //kernel.Bind<IRole>().To<Role>();
            //kernel.Bind<IUser>().To<User>();
            //kernel.Bind<ICategoryViewModel>().To<CategoryViewModel>();
            //kernel.Bind<IOrderViewModel>().To<OrderViewModel>();
            //kernel.Bind<IProductViewModel>().To<ProductViewModel>();
            //kernel.Bind<IUserViewModel>().To<UserViewModel>();
        }

    }
}