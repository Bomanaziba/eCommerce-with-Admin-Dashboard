﻿using Shop.Domain.Model;
using System.Collections.Generic;

namespace Shop.Interface
{
    public interface IProductRepository
    {
        /// <summary>
        /// Gets the products.
        /// </summary>
        /// <value>
        /// The products.
        /// </value>
        IEnumerable<ProductDTO> Products { get; }
        /// <summary>
        /// 
        /// </summary>
        IEnumerable<DigitalFile> DigitalFiles { get; }
        /// <summary>
        /// Gets the specified contact identifier.
        /// </summary>
        /// <param name="contactId">The contact identifier.</param>
        /// <returns></returns>
        ProductDTO Get(int contactId);
        /// <summary>
        /// Gets the category.
        /// </summary>
        /// <value>
        /// The category.
        /// </value>
        IEnumerable<CategoryDTO> Categories { get; }
        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns></returns>
        List<ProductDTO> GetAll();
        /// <summary>
        /// Adds the specified contact.
        /// </summary>
        /// <param name="contact">The contact.</param>
        void Add(ProductDTO contact);
        /// <summary>
        /// Updates the specified contact.
        /// </summary>
        /// <param name="contact">The contact.</param>
        void Update(ProductDTO contact);
        /// <summary>
        /// Deletes the specified contact identifier.
        /// </summary>
        /// <param name="contactId">The contact identifier.</param>
        void Delete(int contactId);
        /// <summary>
        /// Saves the changes.
        /// </summary>
        void SaveChanges();
    }
}
