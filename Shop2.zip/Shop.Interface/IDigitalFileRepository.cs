﻿using Shop.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Interface
{
    public interface IDigitalFileRepository
    {
        /// <summary>
        /// Adds the product.
        /// </summary>
        /// <param name="digitalFile">The digital file.</param>
        void Add(DigitalFile digitalFile);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="digitalId"></param>
        /// <returns></returns>
        DigitalFile Get(int? digitalId);
        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns></returns>
        List<DigitalFile> GetAll();
        /// <summary>
        /// Deletes the specified digital file identifier.
        /// </summary>
        /// <param name="digitalFileId">The digital file identifier.</param>
        void Delete(int digitalFileId);
        /// <summary>
        /// Saves the changes.
        /// </summary>
        void SaveChanges();
        /// <summary>
        /// Updates the specified digital file.
        /// </summary>
        /// <param name="digitalFile">The digital file.</param>
        void Update(DigitalFile digitalFile);
    }
}
