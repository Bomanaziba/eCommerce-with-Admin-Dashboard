﻿using Shop.Domain.Model;
using Shop.Domain.ViewModel.Shop;
using System.Collections.Generic;

namespace Shop.Interface
{
    public interface ICategoryRepository
    {
        /// <summary>
        /// Gets the specified category identifier.
        /// </summary>
        /// <param name="categoryId">The category identifier.</param>
        /// <returns></returns>
        CategoryDTO Get(int? categoryId);

        /// <summary>
        /// Gets all.
        /// </summary>
        /// <returns></returns>
        List<CategoryDTO> GetAll();


        /// <summary>
        /// Adds the specified category.
        /// </summary>
        /// <param name="category">The category.</param>
        void Add(CategoryDTO category);


        /// <summary>
        /// Updates the specified category.
        /// </summary>
        /// <param name="category">The category.</param>
        void Update(CategoryDTO category);


        /// <summary>
        /// Deletes the specified category identifier.
        /// </summary>
        /// <param name="categoryId">The category identifier.</param>
        void Delete(int categoryId);

        /// <summary>
        /// Saves the changes.
        /// </summary>
        void SaveChanges();

    }
}
