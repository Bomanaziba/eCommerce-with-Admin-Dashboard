﻿using Shop.Domain.Model;
using System.Collections.Generic;

namespace Shop.Interface
{
    public interface IUserRepository
    {
        UserDTO Get(int contactId);

        List<UserDTO> GetAll();

        void Add(UserDTO contact);

        void Update(UserDTO contact);

        void Delete(int contactId);

        void SaveChanges();
    }
}
