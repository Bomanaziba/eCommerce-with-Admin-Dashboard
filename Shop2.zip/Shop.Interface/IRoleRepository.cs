﻿using Shop.Domain.Model;
using System.Collections.Generic;

namespace Shop.Interface
{
    public interface IRoleRepository
    {
        RoleDTO Get(int contactId);

        List<RoleDTO> GetAll();

        void Add(RoleDTO contact);

        void Update(RoleDTO contact);

        void Delete(int contactId);

        void SaveChanges();
    }
}
