﻿USE [AlphaXStore]
GO

/****** Object: Table [dbo].[tblOrderDetails] Script Date: 8/5/2018 2:23:26 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblOrderDetails] (
    [Id]        INT      IDENTITY (1, 1) NOT NULL,
    [UserId]    INT      NULL,
    [ProductId] INT      NULL,
    [Quantity]  INT      NULL,
    [OrderId]   INT      NULL,
    [IsActive]  BIT      NULL,
    [CreatedAt] DATETIME NULL
);


