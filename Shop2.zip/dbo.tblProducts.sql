﻿USE [AlphaXStore]
GO

/****** Object: Table [dbo].[tblProducts] Script Date: 8/5/2018 2:25:32 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblProducts] (
    [Id]           INT             IDENTITY (1, 1) NOT NULL,
    [Name]         VARCHAR (50)    NULL,
    [Slug]         VARCHAR (50)    NULL,
    [Description]  VARCHAR (MAX)   NULL,
    [Price]        NUMERIC (18, 2) NULL,
    [CategoryName] VARCHAR (50)    NULL,
    [CategoryId]   INT             NULL,
    [ImageName]    VARCHAR (100)   NULL,
    [IsActive]     BIT             NULL,
    [CreatedAt]    DATETIME2 (7)   NULL
);


