﻿USE [AlphaXStore]
GO

/****** Object: Table [dbo].[tblCategories] Script Date: 8/5/2018 2:16:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[tblCategories] (
    [Id]        INT          IDENTITY (1, 1) NOT NULL,
    [Name]      VARCHAR (50) NULL,
    [Slug]      VARCHAR (50) NULL,
    [Sorting]   INT          NULL,
    [IsActive]  BIT          NULL,
    [CreatedAt] DATETIME     NULL
);


